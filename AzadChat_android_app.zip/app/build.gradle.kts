plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.azadchat.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.azadchat.app"; minSdk = 24; targetSdk = 34; versionCode = 1157; versionName = "1.15.7" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.biometric:biometric:1.1.0")
}
