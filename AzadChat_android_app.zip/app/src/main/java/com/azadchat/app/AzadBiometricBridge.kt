package com.azadchat.app   // ← با package برنامهٔ خودت عوض کن

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec

/**
 * AzadChat v1.56 — پل اثر انگشت بومی برای APK.
 * سایت (az-bio.js) این شیء را به‌صورت window.AzadNative می‌بیند و به‌جای WebAuthn از آن استفاده می‌کند.
 * کلید EC P-256 داخل Android Keystore ساخته می‌شود و فقط با اثر انگشت قابل استفاده است؛ سرور امضا را با کلید عمومی تأیید می‌کند.
 * استفاده:  webView.addJavascriptInterface(AzadBiometricBridge(this, webView), "AzadNative")
 */
class AzadBiometricBridge(private val activity: FragmentActivity, private val web: WebView) {
    private val ks: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private fun alias(keyId: String) = "azad_bio_$keyId"
    private fun b64u(b: ByteArray) = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    @JavascriptInterface
    fun bioAvailable(): String = when (BiometricManager.from(activity).canAuthenticate(BIOMETRIC_STRONG)) {
        BiometricManager.BIOMETRIC_SUCCESS -> "ok"
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "none"
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE, BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "nohw"
        else -> "unsupported"
    }

    /** op = "enroll" (ساخت کلید + امضا) یا "sign" (امضا با کلید موجود). نتیجه با window.__azNativeBio برمی‌گردد. */
    @JavascriptInterface
    fun bio(reqId: String, op: String, keyId: String, payload: String, title: String) {
        activity.runOnUiThread {
            try {
                val sig = Signature.getInstance("SHA256withECDSA")
                var pubKey: ByteArray? = null
                if (op == "enroll") {
                    if (ks.containsAlias(alias(keyId))) ks.deleteEntry(alias(keyId))
                    val b = KeyGenParameterSpec.Builder(alias(keyId), KeyProperties.PURPOSE_SIGN)
                        .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                        .setDigests(KeyProperties.DIGEST_SHA256)
                        .setUserAuthenticationRequired(true)
                        .setInvalidatedByBiometricEnrollment(true)
                    if (android.os.Build.VERSION.SDK_INT >= 30)
                        b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)   // برای هر امضا یک‌بار اثر انگشت
                    val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
                    kpg.initialize(b.build()); pubKey = kpg.generateKeyPair().public.encoded
                }
                val pk = ks.getKey(alias(keyId), null) as? PrivateKey
                    ?: return@runOnUiThread reply(reqId, false, err("nokey"))
                sig.initSign(pk)
                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title).setSubtitle("با اثر انگشت تأیید کن")
                    .setNegativeButtonText("لغو").setAllowedAuthenticators(BIOMETRIC_STRONG).setConfirmationRequired(false).build()
                val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                        try {
                            val s = r.cryptoObject!!.signature!!
                            s.update(payload.toByteArray(Charsets.UTF_8))
                            val o = JSONObject().put("keyId", keyId).put("signature", b64u(s.sign()))
                            if (pubKey != null) o.put("publicKey", b64u(pubKey))
                            reply(reqId, true, o.toString())
                        } catch (e: Exception) { reply(reqId, false, err("cancel")) }
                    }
                    override fun onAuthenticationError(code: Int, msg: CharSequence) {
                        if (op == "enroll") ks.deleteEntry(alias(keyId))
                        val lock = code == BiometricPrompt.ERROR_LOCKOUT || code == BiometricPrompt.ERROR_LOCKOUT_PERMANENT
                        reply(reqId, false, err(if (lock) "lockout" else "cancel"))
                    }
                })
                prompt.authenticate(info, BiometricPrompt.CryptoObject(sig))
            } catch (e: KeyPermanentlyInvalidatedException) {
                reply(reqId, false, err("invalidated"))
            } catch (e: Exception) {
                reply(reqId, false, err("cancel"))
            }
        }
    }

    private fun err(code: String) = JSONObject().put("error", code).toString()
    private fun reply(reqId: String, ok: Boolean, json: String) {
        web.post { web.evaluateJavascript("window.__azNativeBio(${JSONObject.quote(reqId)},$ok,${JSONObject.quote(json)})", null) }
    }
}
