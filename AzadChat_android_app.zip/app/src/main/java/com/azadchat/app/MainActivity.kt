package com.azadchat.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/** پوستهٔ WebView برای AzadChat + پل اثر انگشت بومی (window.AzadNative). آدرس سایت را در START_URL عوض کن. */
class MainActivity : AppCompatActivity() {
    companion object { const val START_URL = "https://azadchat.gt.tc/" }

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val res: Array<Uri>? = if (r.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri } else data.data?.let { arrayOf(it) }
        } else null
        fileCb?.onReceiveValue(res); fileCb = null
    }
    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pendingPerm?.let { p -> p.grant(p.resources) }; pendingPerm = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this); setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = true
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, false) }
        // فقط همین دامنه داخل WebView باز می‌شود؛ شیء AzadNative برای صفحه‌های دیگر در دسترس نیست.
        web.addJavascriptInterface(AzadBiometricBridge(this, web), "AzadNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (u.host == Uri.parse(START_URL).host) return false
                startActivity(Intent(Intent.ACTION_VIEW, u)); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { pickFile.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    val need = mutableListOf<String>()
                    if (req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) need += Manifest.permission.RECORD_AUDIO
                    if (req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) need += Manifest.permission.CAMERA
                    val missing = need.filter { ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED }
                    if (missing.isEmpty()) req.grant(req.resources) else { pendingPerm = req; askPerms.launch(missing.toTypedArray()) }
                }
            }
        }
        web.setDownloadListener { url, ua, cd, mime, _ ->
            val r = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime); addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: ""); addRequestHeader("User-Agent", ua)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
        }
        if (savedInstanceState == null) web.loadUrl(START_URL) else web.restoreState(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); web.saveState(o) }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
